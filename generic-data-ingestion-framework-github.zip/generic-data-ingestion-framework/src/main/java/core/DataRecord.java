package core;

import java.util.Map;

public class DataRecord {
    private Map<String, Object> fields;

    public DataRecord(Map<String, Object> fields) {
        this.fields = fields;
    }

    public Map<String, Object> getFields() {
        return fields;
    }

    public void setFields(Map<String, Object> fields) {
        this.fields = fields;
    }

    @Override
    public String toString() {
        return "DataRecord{" + "fields=" + fields + '}';
    }
}
