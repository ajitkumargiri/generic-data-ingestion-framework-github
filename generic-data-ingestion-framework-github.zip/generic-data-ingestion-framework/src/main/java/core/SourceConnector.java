package core;

import java.util.Map;
import java.util.function.Consumer;
import java.util.stream.Stream;

public interface SourceConnector {
    void configure(Map<String, String> config);
    Stream<DataRecord> readBatch();
    default void listen(Consumer<DataRecord> consumer) {
        throw new UnsupportedOperationException("Stream mode not implemented");
    }
}
