package core;

import connectors.sink.KafkaSinkConnector;
import connectors.source.RestApiSourceConnector;
import java.util.Map;
import java.util.stream.Stream;

public class PipelineRunner {

    private SourceConnector sourceConnector;
    private SinkConnector sinkConnector;

    public PipelineRunner(PipelineConfig config) {
        sourceConnector = createSource(config.getSourceType());
        sinkConnector = createSink(config.getSinkType());

        sourceConnector.configure(config.getSourceConfig());
        sinkConnector.configure(config.getSinkConfig());
    }

    private SourceConnector createSource(String type) {
        switch (type.toLowerCase()) {
            case "rest-api":
                return new RestApiSourceConnector();
            default:
                throw new RuntimeException("Unknown source type: " + type);
        }
    }

    private SinkConnector createSink(String type) {
        switch (type.toLowerCase()) {
            case "kafka":
                return new KafkaSinkConnector();
            default:
                throw new RuntimeException("Unknown sink type: " + type);
        }
    }

    public void runBatch() {
        Stream<DataRecord> records = sourceConnector.readBatch();
        sinkConnector.write(records);
    }
}
