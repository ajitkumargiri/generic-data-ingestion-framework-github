package core;

import java.util.Map;

public class PipelineConfig {
    private String sourceType;
    private Map<String, String> sourceConfig;
    private String sinkType;
    private Map<String, String> sinkConfig;

    public PipelineConfig(String sourceType, Map<String, String> sourceConfig,
                          String sinkType, Map<String, String> sinkConfig) {
        this.sourceType = sourceType;
        this.sourceConfig = sourceConfig;
        this.sinkType = sinkType;
        this.sinkConfig = sinkConfig;
    }

    public String getSourceType() {
        return sourceType;
    }

    public Map<String, String> getSourceConfig() {
        return sourceConfig;
    }

    public String getSinkType() {
        return sinkType;
    }

    public Map<String, String> getSinkConfig() {
        return sinkConfig;
    }
}
