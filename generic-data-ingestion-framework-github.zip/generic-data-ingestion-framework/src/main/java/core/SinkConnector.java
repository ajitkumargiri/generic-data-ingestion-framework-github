package core;

import java.util.Map;
import java.util.stream.Stream;

public interface SinkConnector {
    void configure(Map<String, String> config);
    void write(Stream<DataRecord> records);
}
