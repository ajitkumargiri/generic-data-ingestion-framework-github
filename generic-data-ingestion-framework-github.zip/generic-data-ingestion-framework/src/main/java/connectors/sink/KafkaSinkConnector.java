package connectors.sink;

import core.DataRecord;
import core.SinkConnector;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;

import java.util.Map;
import java.util.Properties;
import java.util.concurrent.Future;
import java.util.stream.Stream;

public class KafkaSinkConnector implements SinkConnector {

    private KafkaProducer<String, String> producer;
    private String topic;

    @Override
    public void configure(Map<String, String> config) {
        this.topic = config.get("topic");

        Properties props = new Properties();
        props.put("bootstrap.servers", config.get("bootstrap.servers"));
        props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        this.producer = new KafkaProducer<>(props);
    }

    @Override
    public void write(Stream<DataRecord> records) {
        records.forEach(record -> {
            String key = (String) record.getFields().getOrDefault("id", UUID.randomUUID().toString());
            String value = record.getFields().toString();
            ProducerRecord<String, String> producerRecord = new ProducerRecord<>(topic, key, value);
            try {
                Future<RecordMetadata> future = producer.send(producerRecord);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
        producer.flush();
    }
}
