package connectors.source;

import core.DataRecord;
import core.SourceConnector;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.URI;
import java.time.Duration;
import java.util.*;
import java.util.stream.Stream;

public class RestApiSourceConnector implements SourceConnector {

    private String url;
    private HttpClient httpClient;
    private ObjectMapper mapper;

    @Override
    public void configure(Map<String, String> config) {
        this.url = config.get("url");
        this.httpClient = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(10))
                .build();
        this.mapper = new ObjectMapper();
    }

    @Override
    public Stream<DataRecord> readBatch() {
        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .GET()
                    .build();

            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            String body = response.body();

            JsonNode rootNode = mapper.readTree(body);
            if (rootNode.isArray()) {
                List<DataRecord> records = new ArrayList<>();
                for (JsonNode node : rootNode) {
                    Map<String, Object> fields = mapper.convertValue(node, Map.class);
                    records.add(new DataRecord(fields));
                }
                return records.stream();
            } else {
                Map<String, Object> fields = mapper.convertValue(rootNode, Map.class);
                return Stream.of(new DataRecord(fields));
            }

        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
            return Stream.empty();
        }
    }
}
